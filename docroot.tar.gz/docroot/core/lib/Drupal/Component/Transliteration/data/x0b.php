<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => NULL, 'N', 'm', 'h', NULL, 'a', 'a', 'i', 'i', 'u', 'u', 'r', 'l', NULL, NULL, 'e',
  0x10 => 'ai', NULL, NULL, 'o', 'au', 'ka', 'kha', 'ga', 'gha', 'na', 'ca', 'cha', 'ja', 'jha', 'na', 'ta',
  0x20 => 'tha', 'da', 'dha', 'na', 'ta', 'tha', 'da', 'dha', 'na', NULL, 'pa', 'pha', 'ba', 'bha', 'ma', 'ya',
  0x30 => 'ra', NULL, 'la', 'la', NULL, 'va', 'sa', 'sa', 'sa', 'ha', NULL, NULL, '\'', '\'', 'a', 'i',
  0x40 => 'i', 'u', 'uu', 'R', NULL, NULL, NULL, 'e', 'e', NULL, NULL, 'o', 'au', '', NULL, NULL,
  0x50 => NULL, NULL, NULL, NULL, NULL, NULL, '+', '+', NULL, NULL, NULL, NULL, 'da', 'dha', NULL, 'ya',
  0x60 => 'r', 'l', NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => '', 'wa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x80 => NULL, NULL, 'N', 'h', NULL, 'a', 'a', 'i', 'i', 'u', 'u', NULL, NULL, NULL, 'e', 'e',
  0x90 => 'ai', NULL, 'o', 'o', 'au', 'ka', NULL, NULL, NULL, 'na', 'ca', NULL, 'ja', NULL, 'na', 'ta',
  0xA0 => NULL, NULL, NULL, 'na', 'ta', NULL, NULL, NULL, 'na', 'na', 'pa', NULL, NULL, NULL, 'ma', 'ya',
  0xB0 => 'ra', 'ra', 'la', 'la', 'la', 'va', 'sa', 'sa', 'sa', 'ha', NULL, NULL, NULL, NULL, 'a', 'i',
  0xC0 => 'ii', 'u', 'u', NULL, NULL, NULL, 'e', 'e', 'ai', NULL, 'o', 'o', 'au', '', NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, '+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => '10', '100', '1000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
);
