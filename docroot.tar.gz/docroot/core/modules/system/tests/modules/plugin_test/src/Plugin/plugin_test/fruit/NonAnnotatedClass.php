<?php

namespace Drupal\plugin_test\Plugin\plugin_test\fruit;

class NonAnnotatedClass {}
