<?php

namespace Drupal\field_ui\Form;

/**
 * Provides the edit form for entity display modes.
 */
class EntityDisplayModeEditForm extends EntityDisplayModeFormBase {

}
